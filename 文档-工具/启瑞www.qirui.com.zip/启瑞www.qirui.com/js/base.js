
//注册
var flag = true;

$("body").on("click", ".register_id", function () {
    //关闭其他弹出层;
    layer.closeAll();
    layer.open({
        type: 1,
        skin: 'layui-layer-demo', //样式类名
        closeBtn: 1, //显示关闭按钮
        anim: 0,
        title: false,
        area: ['430px', 'auto'],
        shadeClose: true, //开启遮罩关闭
        content: $('#zhuce')
    });
});

function checkMobile(str) {
    var re = /^1([3578]\d|4[57])\d{8}$/;
    if (re.test(str.val())) {
        $('#mobileMsg').hide();
        return true;
    } else {

        $('#mobileMsg').show();
        $('#mobileMsg').text('请输入正确手机号！');
        return false;
    }
}
function sendCode() {
    var regex = /^1([3578]\d|4[57])\d{8}$/;
    if (!regex.test($('#mobile').val())) {
        layer.msg('请输入正确手机号！');
        return false;
    }
    if ($('#imageCode').val()=='') {
        layer.msg('请输入图形验证码', {time: 1000, icon: 2});
        return false;
    }
    if (!flag) {
        return false;
    }
    $.ajax({
        type: "POST",
        url: 'http://www.qirui.com/api/user/Sms/send/',
        data: {telephone:$("#mobile").val(),code: $('#imageCode').val(),type:2},
        dataType: "json",
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        async: true,
        success: function(re){
            if (re.code == '10001023') {
                setDisabled(60, $('#sendBtn'));
                layer.msg('验证码短信已发送，请及时查看', {time: 1000, icon: 1})
            }else if(re.code == '10001003'){
                layer.msg('图形验证码错误'+  "  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  错误代码：" + re.code, {time: 1000, icon:2})
            } else {
                layer.msg(re.msg +  "  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  错误代码：" + re.code, {time: 1000, icon:2})
            }
        }
    });
}


//确认注册
function submit() {
    var mobile = $("#mobile");
    if (!checkMobile(mobile)) {
        layer.msg('请输入正确手机号！');
        return false;
    }
    if ($('#smsCode').val()==''){
        layer.msg('请输入短信验证码！');
        return false;
    }
    if ($("#password").val()==''){
        layer.msg('请输入您的密码！');
        return false;
    }

    $.ajax({
        type: "POST",
        url: 'http://www.qirui.com/api/user/Register/register',
        data:{telephone:$("#mobile").val(), password:$("#password").val(), sms_code: $('#smsCode').val(),qq:$('#qq').val()},
        dataType: "json",
        async: true,
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        success: function(re){
            if (re.code == 10001050) {
                window.location.href = 'http://sms.qirui.com';
            } else {
                layer.msg(re.msg + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;错误代码：" + re.code, {time: 1000, icon:2})
            }
            $('#register-submit-btn').text('确认注册');
            $('#register-submit-btn').removeAttr('disabled');
        }
    });

}
$('#to_login').on('click',function () {
    window.location.href= 'http://sms.qirui.com'
})
// 发送倒计时
function setDisabled(seconds, o) {
    if (seconds <= 0) {
        o.removeAttr("disabled");
        o.html('发送验证码');
    } else {
        o.attr('disabled', true);

        o.html('重新发送 ( ' + (seconds < 10 ? '0': '') + seconds + ' )');
        seconds --;
        setTimeout(function () {
            setDisabled(seconds, o);
        }, 1000);
    }
}




(function(){
    var c=document.createElement('script');
    c.src='//kefu.qycn.com/vclient/state.php?webid=131142';
    var s=document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(c,s);
})();
