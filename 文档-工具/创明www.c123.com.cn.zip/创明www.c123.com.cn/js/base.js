/**
 * Created by Administrator on 2017/1/17 0017.
 */
function inc() {
    $(".nav ul li").on("click",function () {
        $(this).addClass("current").siblings().removeClass("current")
    })
//        轮播图
    $('.flexslider').flexslider({
        animation: "fade",              //String: Select your animation type, "fade" or "slide"图片变换方式：淡入淡出或者滑动
        slideDirection: "horizontal",   //String: Select the sliding direction, "horizontal" or "vertical"图片设置为滑动式时的滑动方向：左右或者上下
        slideshow: true,                //Boolean: Animate slider automatically 载入页面时，是否自动播放
        slideshowSpeed: 4000,           //Integer: Set the speed of the slideshow cycling, in milliseconds 自动播放速度毫秒
        animationDuration: 600,         //Integer: Set the speed of animations, in milliseconds动画淡入淡出效果延时
        directionNav: false,             //Boolean: Create navigation for previous/next navigation? (true/false)是否显示左右控制按钮
        controlNav: true,               //Boolean: Create navigation for paging control of each clide? Note: Leave true for manualControls usage是否显示控制菜单
        keyboardNav: true,              //Boolean: Allow slider navigating via keyboard left/right keys键盘左右方向键控制图片滑动
        mousewheel: false,              //Boolean: Allow slider navigating via mousewheel鼠标滚轮控制制图片滑动
        prevText: "Previous",           //String: Set the text for the "previous" directionNav item
        nextText: "Next", //String: Set the text for the "next" directionNav item
        pausePlay: false,               //Boolean: Create pause/play dynamic element
        pauseText: 'Pause',             //String: Set the text for the "pause" pausePlay item
        playText: 'Play',               //String: Set the text for the "play" pausePlay item
        randomize: false,               //Boolean: Randomize slide order 是否随即幻灯片
        slideToStart: 0,                //Integer: The slide that the slider should start on. Array notation (0 = first slide)初始化第一次显示图片位置
        animationLoop: true,            //Boolean: Should the animation loop? If false, directionNav will received "disable" classes at either end 是否循环滚动
        pauseOnAction: false,            //Boolean: Pause the slideshow when interacting with control elements, highly recommended.
        pauseOnHover: false,            //Boolean: Pause the slideshow when hovering over slider, then resume when no longer hovering
        controlsContainer: "",          //Selector: Declare which container the navigation elements should be appended too. Default container is the flexSlider element. Example use would be ".flexslider-container", "#container", etc. If the given element is not found, the default action will be taken.
        manualControls: ".flex-control-nav li",             //Selector: Declare custom control navigation. Example would be ".flex-control-nav li" or "#tabs-nav li img", etc. The number of elements in your controlNav should match the number of slides/tabs.自定义控制导航
        manualControlEvent:"click",          //String:自定义导航控制触发事件:默认是click,可以设定hover
        start: function(){},            //Callback: function(slider) - Fires when the slider loads the first slide
        before: function(){},           //Callback: function(slider) - Fires asynchronously with each slider animation
        after: function(){},            //Callback: function(slider) - Fires after each slider animation completes
        end: function(){}               //Callback: function(slider) - Fires when the slider reaches the last slide (asynchronous)

    });
//        轮播图

//        导航图片
    var time=null;
    $(".ftp-4 .exhibition .box ul li").each(function (index) {
        $(this).css("background","url(/cm/images/home_fa"+(index+1)+".png)")
    }).mouseenter(function () {
//        clearTimeout(time);
//        $this=$(this);
//        time=setTimeout(function () {
//            $this.children().slideDown();
//        },300)

    }).mouseleave(function () {
//        clearTimeout(time);
//        $(this).children().slideUp();
    })

//        导航图片2
    var flag = "left";
    function DY_scroll(wraper,prev,next,img,imga,speed,or){
        var wraper = $(wraper);
        var prev = $(prev);
        var next = $(next);
        var img = $(img).find('ul');
        var imga = $(imga).find('li');
        var w = img.find('li').outerWidth(true);
        var s = speed;
        next.click(function(){
            img.animate({'margin-left':-w}/*,1500,'easeOutBounce'*/,function(){
                img.find('li').eq(0).appendTo(img);
                img.css({'margin-left':0});
            });
            flag = "left";
        });
        prev.click(function(){
            img.find('li:last').prependTo(img);
            img.css({'margin-left':-w});
            img.animate({'margin-left':0}/*,1500,'easeOutBounce'*/);
            flag = "right";
        });
        if(imga.length>4){
            if (or == true){
                ad = setInterval(function() { flag == "left" ? next.click() : prev.click()},s*1000);
                wraper.hover(function(){clearInterval(ad);},function(){ad = setInterval(function() {flag == "left" ? next.click() : prev.click()},s*1000);});
            }
        }

    }
    DY_scroll('.ftp_end','.prev','.next','.ftp_end_list','.ftp_end_list',2,true);// true为自动播放，不加此参数或false就默认不自动

//    //添加浮动客服
//    $("body").prepend('' +
//        '<div  id="sslider" style="border-radius:0 5px 5px 0;width: 35px;height: 135px;background-color: #249bd7;position: absolute;top: 50%;left: 0;z-index: 4"> ' +
//        '<a href="" style="display: block;color: #fff;">' +
//        '<img src="../../../images/float.png"/*tpa=http://www.c123.com.cn/images/float.png*/ alt="">' +
//        '</a>' +
//        '</div>'
//    )
//    //浮动按钮
//    var ppp=$("#sslider").position().top;
//    $(window).scroll(function () {
//        var dtop=$(document).scrollTop();
//        $("#sslider").animate({"top": dtop+ppp},30);
//
//    });
    
    //切换
    $(".nav ul li").on("mouseover", function () {
        $(this).addClass("current").siblings().removeClass("current")
    })
    $(".main-l ul li").on("click", function () {
        var index=$(this).index();
        $(this).addClass("current").siblings().removeClass("current");
        $("#mainr .pro-detail").eq(index).addClass("active").siblings().removeClass("active");
    })
    
    //点击显示
    $(".recruit-list").on("click",function(){
        var id = $(this).data("id");
        var sel = $(".showjob[data-id='"+id+"']");
        if(sel.hasClass("showbox")){
            sel.removeClass("showbox");
            $(".imgstop",this).attr("src", "../images/arrow_down.png"/*tpa=http://www.c123.com.cn/templets/cming/images/arrow_down.png*/);
        }else{
            sel.addClass("showbox");
            $(".imgstop",this).attr("src", "../images/arrow_up.png"/*tpa=http://www.c123.com.cn/templets/cming/images/arrow_up.png*/);
        }
    })
}
inc();
