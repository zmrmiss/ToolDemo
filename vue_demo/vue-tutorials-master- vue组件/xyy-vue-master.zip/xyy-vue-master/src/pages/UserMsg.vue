<template>
	<div class="">
		<msg-list></msg-list>
	</div>
</template>

<script>

import msgList from '@/components/msgList'

export default {

	components: {
		msgList
	},
	data() {
		return {
			
		}
	},
}
</script>